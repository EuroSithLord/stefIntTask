﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stefanini
{
    public class cook
    {
        public string nume;
        public int comenzi;

        public cook()
        {
            nume = "";
            comenzi = 0;
        }
        public cook(string nume, int comenzi)
        {
            this.nume = nume;
            this.comenzi = comenzi;
        }


    }
}
