﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data.SqlTypes;

namespace Stefanini
{
    public class Ingredient
    {
        protected string name;
        protected int price;

        public Ingredient()
        {
            name = ""; 
            price = 0;
        }
        public Ingredient(string name, int price)
        {
            this.name = name;
            this.price = price;
        }

        public void CitireIngredient(int i)
        {
            string path = @"..\stefanini_ingr.txt";
            string[] lines = File.ReadAllLines(path);
            if (i % 2==0)
            {
                this.name = lines[i];
            }
            else
            {
                this.price = Convert.ToInt32(lines[i]);
            }
                    
            //Based on array cell element type determine ....
            /*Type t = lines.GetType();
            Type t2 = t.GetElementType();
            Console.WriteLine("The element type of {0} is {1}.", lines[2], t2.ToString());
            //foreach (string line in lines)
            //Console.WriteLine(line);*/
        }

        public void AfisareIngredientName()
        {
            Console.Write("{0}, ", this.name);
        }

        public void AfisareIngredientPrice()
        {
            Console.WriteLine("{0} ", this.price, " lei");
        }
    }
}
