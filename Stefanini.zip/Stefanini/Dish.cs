﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Stefanini
{
    class Dish:Ingredient
    {
        private string nameDish;
        private string description;
        private int priceDish;
        private int minutes;

        public Dish()
        {
            nameDish = "";
            priceDish = 0;
            description = "";
            minutes = 0;
        }

        public Dish(string nameDish, string description, int priceDish, int minutes)
        {
            this.nameDish = nameDish;
            this.priceDish = priceDish;
            this.minutes = minutes;
            this.description = description;
        }

        public void Dishes(int i)
        {
            string pathName = @"..\stefanini_dish_name.txt";
            string[] names = File.ReadAllLines(pathName);
            nameDish = names[i];
            string pathDescription = @"..\stefanini_dish_description.txt";
            string[] desc = File.ReadAllLines(pathDescription);
            description = desc[i];
            Random rnd = new Random();
            minutes = rnd.Next(10, 30);
        }

        public void AfisareDishesPartial()
        {
            Console.WriteLine("{0}", this.nameDish);
            Console.WriteLine("{0}", this.description);
            Console.WriteLine("Timp de preparare: {0}", this.minutes, " minute");
            Console.WriteLine("Ingrediente: ");
        }
        
        public int PretDish()
        {
            return price;
        }

    }
}
