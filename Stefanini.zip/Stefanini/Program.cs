﻿using System;


namespace Stefanini
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Meniu:");
            Ingredient[] ingrediente = new Ingredient[10];
            for (int i = 0; i < ingrediente.Length; i++)
            {
                ingrediente[i] = new Ingredient();
                ingrediente[i].CitireIngredient(i);
            }

            Dish[] dishes = new Dish[4];
            for (int i=0; i<dishes.Length; i++)
            {
                dishes[i] = new Dish();
                dishes[i].Dishes(i);
            }
            for (int i = 0; i < dishes.Length; i++)
            {
                dishes[i].AfisareDishesPartial();
                Random rnd = new Random();
                int tmp = 0;
                for (int j = 0; j < 6; j++)
                {
                    tmp = rnd.Next(0, 9);
                    if (tmp%2==0)
                        ingrediente[tmp].AfisareIngredientName();
                }
                Console.WriteLine();
                Console.WriteLine();
            }

            
            Console.WriteLine("\n\n\n Comanda: ?");
            string cmd = Console.ReadLine();

        }
    }
}
